const resultsNav = document.getElementById('resultsNav');
const favoritesNav = document.getElementById('favoritesNav');
const imagesContainer = document.querySelector('.images-container');
const linkContainer = document.querySelector('.full-screen-container');
const saveConfirmed = document.querySelector('.save-confirmed');
const loader = document.querySelector('.loader-wrapper');


// NASA API
const count = 1;
const apiKey = 'QeNL0N8fiY0mmeSbb0xGwqNpeK2HW1lUxne0I1bB';
const apiUrl = `https://api.nasa.gov/planetary/apod?api_key=${apiKey}&count=${count}`;

let resultsArray = [];
let favorites = {};

function createDOMNOdes(page) {
    const currentArray = page === 'results' ? resultsArray : Object.values(favorites);
    currentArray.forEach((result)  => {
        // Card Container
        const card = document.createElement('div');
        card.classList.add('card');
        // Link
        const link = document.createElement('a');
        link.href = result.hdurl;
        link.title = 'View Full Image';
        link.target = '_blank';
        // Image
        const image = document.createElement('img');
        image.src = result.url;
        image.alt = 'NASA Picture of the Day';
        image.loading = 'lazy';
        image.classList.add('card-img-top');
        // Card Body
        const cardBody = document.createElement('div');
        cardBody.classList.add('card-body');
        cardBody.id = 'cardBodyPos';
        // Card Title
        const cardTitle = document.createElement('h5');
        cardTitle.classList.add('card-title');
        cardTitle.textContent = result.title;
        // Card Text
        const cardText = document.createElement('p');
        cardText.textContent = result.explanation;
        // Footer Container
        const footer = document.createElement('small');
        footer.classList.add('text-muted');
        // Date
        const date = document.createElement('strong');
        date.textContent = result.date;
        // Copyright
        const copyrightResult = result.copyright === undefined ? '' : result.copyright;
        const copyright = document.createElement('span');
        copyright.textContent = ` ${copyrightResult}`;
        // Footer Link Container
        const footerLink = document.createElement('div');
        footerLink.classList.add('footer-link');
        // Save Text
        const saveText = document.createElement('a');
        saveText.classList.add('clickable');
        if (page === 'results') {
            saveText.textContent = 'Like';
        saveText.setAttribute('onclick', `saveFavorite('${result.url}')`);
        } else {
            saveText.textContent = 'Remove Favourite';
        saveText.setAttribute('onclick', `removeFavorite('${result.url}')`);
        }
        // Card View Full Image
        const cardFullScreen = document.createElement('a');
        cardFullScreen.classList.add('full-screen');
        cardFullScreen.href = result.hdurl;
        cardFullScreen.title = 'View Full Image';
        cardFullScreen.target = '_blank';
        cardFullScreen.textContent = 'View Full Image';
        // Append
        footerLink.append(saveText, cardFullScreen);
        footer.append(date, copyright);
        cardBody.append(cardTitle, cardText, footer, footerLink );
        link.appendChild(image);
        card.append(link, cardBody);
        imagesContainer.appendChild(card);
    });
}

// Favourites Page
function showContent(page) {
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (page === 'results') {
        resultsNav.classList.remove('hidden');
        favoritesNav.classList.add('hidden');
        // View one image per page
        const section = document.getElementById('section');
        section.style.overflow = 'hidden';
        
    } else {
        resultsNav.classList.add('hidden');
        favoritesNav.classList.remove('hidden');
        // View multiple images per page
        const section = document.getElementById('section');
        section.style.overflow = 'visible';
        section.style.background = '#fff';
        // Line up image descriptions
        // const cardBodyPos = document.querySelector('.card-body');
        const cardBodyPos = document.getElementById('cardBodyPos');
        cardBodyPos.style.position = 'relative';
        // Remove overlay
        const overlay = document.getElementById('overlay');
        overlay.classList.add('hidden');
    }
    loader.classList.add('hidden');
}

function updateDOM(page) {
    // Get Favourites from localStorage
    if(localStorage.getItem('nasaFavorites')) {
        favorites = JSON.parse(localStorage.getItem('nasaFavorites'));
    }
    imagesContainer.textContent = '';
    createDOMNOdes(page);
    showContent(page);
}

// Get Images from NASA API
async function getNasaPictures() {
    // Show Loader
    loader.classList.remove('hidden');
    try {
        const response = await fetch(apiUrl);
        resultsArray = await response.json();
        console.log(resultsArray);
        updateDOM('results');
    } catch (error) {
        // Catch Error Here
    }
}

// Add Result to Favourites
function saveFavorite(itemUrl) {
    // Loop through Results Array to select Favorite
    resultsArray.forEach((item) => {
        if (item.url.includes(itemUrl) && !favorites[itemUrl]) {
            favorites[itemUrl] = item;
            // Show Save Confirmation for 2 seconds
            saveConfirmed.hidden = false;
            setTimeout(() => {
                saveConfirmed.hidden = true;
            }, 5000);
            //Set Favourites in Local Storage
            localStorage.setItem('nasaFavorites', JSON.stringify(favorites));
        }
    });
}

// Remove item from Favourites
function removeFavorite(itemUrl) {
    if (favorites[itemUrl]) {
        delete favorites[itemUrl];
        //Set Favourites in Local Storage
        localStorage.setItem('nasaFavorites', JSON.stringify(favorites));
        updateDOM('favorites');
    }
}

// On Load
getNasaPictures();